# Computation of flow using backwater equations
# see equations 20 to 23 ebook G.Parke, chapter 20 formulation for RTe-bookAgDegBW.xls

# Package import#
import numpy as np
import matplotlib.pyplot as plt
from functions import F_back

# Boundary conditions
Qf = 4000  # Flood discharge (m^3/s)
xi_d = 15  # Base level elevation in m (imposed water level elevation at the
# downstream boundary)
#   Channel and bed characteristics
L = 200000  # Length of reach under consideration (m)
B = 500  # Channel Width (m)
S0 = 0.00016  # Initial bed Slope
kc = 0.15  # Roughness Height (m)

#   Parameters for discretisation (in space):
dx = 100  # Spatial step (m)
Nx = int(
    (np.floor(L / dx))
)  # Number of spatial steps (=nodes-1) (excluding ghost node)

#   Other constants
g = 9.81  # gravitational acceleration in m/s^2
alr = 8.1  # coefficient for Manning-Strickler friction relation


# PRELIMINARY COMPUTATIONS
qw = Qf / B  # water discharge per unit width (at flood) (m^2/s)
#   Initialisation bathymetry
xcoord = np.transpose(np.arange(0, L + 1, dx))  # spatial grid (m)
eta = np.transpose(S0 * (L - xcoord))  # bed elevation (m)

#   Characterization of the flow
Hn = (kc ** (1 / 3) * qw**2 / (alr**2 * g * S0)) ** (
    3 / 10
)  # normal flow depth (m)  %Frn =  sqrt(qw^2/(g*Hn^3))
Hc = (qw**2 / g) ** (1 / 3)  # critical flow depth (Fr=1)
H_d = xi_d - eta[-1]  # actual flow depth at downstream boundary as specified (m)

#   Initialisation water depth array
H = np.full((Nx + 1, 1), np.nan)  # local depth

# COMPUTATION OF THE WATER DEPTH AND ELEVATION
# we solve the backwater equations, starting at the downstream boundary

H[-1] = H_d  # water depth at downstream boundary

for nx in reversed(range(Nx)):
    S = [(eta[nx] - eta[nx + 1]) / dx]  # local bed slope

    # predictor step
    Fbackp = F_back(H[nx + 1], S, qw, kc, g)
    Hp = H[nx + 1] - Fbackp * dx
    # corrector step
    Fbackc = F_back(Hp, S, qw, kc, g)
    H[nx] = H[nx + 1] - (1 / 2) * (Fbackp + Fbackc) * dx

H = np.transpose(H[:, 0])
xi = H + eta  # local water level elevation in m

# Visualisation
plt.figure(1)
plt.plot(xcoord, eta, color="k")
plt.plot(xcoord, xi, color="b")
plt.xlabel("x(m)")
plt.ylabel("elevation(m)")
plt.legend(["bed elevation", "water surface elevation"])
plt.title("Flow computation using backwater equations")
plt.show()
