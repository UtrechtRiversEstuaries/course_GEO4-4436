import numpy as np
import matplotlib.pyplot as plt

def F_back(H, S, qw, kc, g):
    """ Flux function for the backwater equation
    see equ (20b) ebook G. Parker, chapter 20 Formulation for RTe-bookAgDegBW.xls
    Inputs
            S: local slope at the cell under consideration (scalar)
            H: water depth at the cell in m (scalar)
            qw: water discharge in m^2/s
            kc: roughness height in m
    Output
            Fbw: backwater flux (dimensionless)
    """

    alr = 8.1  # coefficient in Manning - Strickler resistance relation
    Cf = (alr * (H / kc) ** (1 / 6)) ** (-2)
    Fr = qw**2 / (g * H**3)
    return (S - Cf * Fr) / (1 - Fr)

def bed_variations(eta0, qt, qt_u, If, lamp, dx, Nx, au, dt):
    """Solve the sediment mass conservation = Exner equation to compute the bed
    elevation.

    Inputs
            eta0: bed elevation at the previous time step (at time t) in m
            qt  : sediment transport in m^2/s
            qt_u: imposed sediment rate at the upstream boundary (sediment
            transport in the ghost cell) m^2/s
            If: flood intermittency
            lamp: bed porosity
            dx: grid size in m
            Nx: Number of cells
            au: coefficient for the numerical scheme. au=1 upwind scheme, au=0.5 central difference scheme (see equ. 22 p7 + explanations ebook)
            dt: time step in years

    Output
            eta: updated bed elevation (at t+dt) in m
    """

    # Computation of sediment transport gradient (equ. (22) ebook) m/s
    # - initialisation of the vector
    dqdx = np.full((Nx + 1, 1), np.nan)
    # - values at the boundaries
    dqdx[-1] = (qt[-1] - qt[Nx]) / dx  # gradient at downstream boundary
    dqdx[0] = (
        au * (qt[0] - qt_u) / dx + (1 - au) * (qt[1] - qt[0]) / dx
    )  # gradient at downstream boundary (qt at the ghost node is qt_u)

    # - computation of dqdx
    for nx in range(1, Nx):  # transport gradient, positive means erosion
        dqdx[nx] = (
            au * (qt[nx] - qt[nx - 1]) / dx + (1 - au) * (qt[nx + 1] - qt[nx]) / dx
        )

    # computation of the bed elevatio at t+dt (equ. (21) ebook)
    ta = 3600 * 24 * 365.25  # number of seconds in a year
    return (
        eta0 - (1 / (1 - lamp)) * dqdx * If * ta * dt
    )  # New bed elevation using Exner equation

def flow_computation(eta, xi_d, qw, kc, dx, Nx, g):
    """Update the flow using backwater equations
    see equ (20) to (23) ebook G. Parker, chapter 20 Formulation for RTe-bookAgDegBW.xls
    Inputs
            eta: bed level elevation in m
            xi_d: base level elevation (imposed water level elevation at the
            downstream boundary) in m
            qw: water discharge at flood in m2/s
            kc: roughness height in m
            dx: grid spacing
            Nx: number of cells
    Outputs
            H: updated local water depth in m
            xi: updated local water level elevation in m
    """

    H = np.full((Nx + 1, 1), np.nan)  # local depth
    H[-1] = xi_d - eta[-1]  # water depth at downstream boundary

    # we solve the backwater equations starting at the downstream boundary
    # Nx+1 (H(Nx+1) is known)

    for nx in reversed(range(Nx)):
        S = [(eta[nx] - eta[nx + 1]) / dx]  # local bed slope

        # predictor step
        Fbackp = F_back(H[nx + 1], S, qw, kc, g)
        Hp = H[nx + 1] - Fbackp * dx
        # corrector step
        Fbackc = F_back(Hp, S, qw, kc, g)
        H[nx] = H[nx + 1] - (1 / 2) * (Fbackp + Fbackc) * dx

    # H = np.transpose(H)
    xi = H + eta  # local water level elevation in m

    return H, xi

