# AgDegBW model of Gary Parker
# see ebook chapter 20 (word file) for detailed explanations on the model and fomulation.
# Based on:
#    - Backwater equations for the flow
#    - Manning-Strickler relation for bed friction
#    - MPM sediment transport predictor for total bed material load
#    - Exner equation for bed variations
# built as Matlab by Maarten Kleinhans, september 2005
# modified by M. Tissier, August 2013

# Package import #
from functions import bed_variations, flow_computation
import numpy as np
import matplotlib.pyplot as plt

##############################################################################
#                   INITIALISATION                                           #
##############################################################################

# DEFINITION VARIABLES AND PARAMETERS

#   Boundary conditions
Qf = 5500  # Flood discharge (m^3/s)
If = 1  # Intermittency
Gtf = 1e07  # Imposed sediment transport rate fed in from upstream (which
# must all be carried during floods) in tons/a
xi_d = 15  # Imposed basin water surface elevation (water level downstream boundary) (m)

#   Channel and bed characteristics
L = 2e5  # Length of reach under consideration (m)
B = 500  # Channel Width (m)
S0 = 0.00016  # Initial bed Slope (-)
D = 2.5e-3  # Median grain Size (m)
Rr = 1.65  # Submerged specific gravity of sediment
lamp = 0.35  # Bed Porosity
kc = 0.01  # Roughness Height (m)

#   Parameters for discretisation:
#   - in space
dx = 1000  # Spatial step (m)
au = 1  # Coefficient for spatial scheme. au=1: full upwind, 0.5: central difference (see equ. 22 page 7 + explanations ebook)
Nx = int(L / dx)  # Number of spatial steps (=nodes-1) (excluding ghost node)

#   - in time
Durat = 10  # Duration of the run (years)
dt = 0.05  # Time step (years)
Nt = int(Durat / dt) + 1  # Number of time steps

#   Other constants
ta = 60 * 60 * 24 * 365.25  # number of seconds in a year
g = 9.81  # gravitational acceleration in m/s^2
rho_w = 1e3  # water density in kg/m^3
rho_s = 2.65e3  # sand density in kg/m^3
R = rho_s / rho_w - 1  # submerged specific density
tausc = 0.047  # critical Shields parameter

#   Sediment transport parameters
a_t = 8
n_t = 1.5
theta_cr = 0.047
phi_s = 1
qt = np.full((Nx + 1, 1), 0)  # qt, sediment transport rate in m2/s, is set to zero

#   Frequency of the outputs
Nreport = 5
# numbers of reports for bed and water level profiles (>6 cyclic colors)
treport = round(Nt / Nreport)
# time step interval for report

# PRELIMINARY COMPUTATIONS #
# imposed discharges in m2/s

qt_u = (
    Gtf * 1e3 / ((Rr + 1) * rho_w * ta * B * If)
)  # sediment transport rate per unit width
# during flood at the ghost
# node (upstream) (m^2/s)
qw = Qf / B  # water discharge per unit width (at flood) (m^2/s)

# initialisation bathymetry
xcoord = np.zeros((Nx + 1, 1))
xcoord[:, 0] = np.arange(0, L + 1, dx)  # spatial grid (m)
eta = -S0 * xcoord + S0 * L  # bed elevation (m) defined such as eta(x=L)=0;

## Initialisation of the ouptput arrays #
# xir and etar will contain the profiles  of surface elevation and bed
#  elevation at different times. They have Nreport+1 columns, each of them
#  being the profiles at the time t=n*treport, with n=0,1,2,...,Nreport

xir = np.full(
    (Nx + 1, Nreport + 1), np.nan
)  # storage of water surface elevation profiles
etar = np.full((Nx + 1, Nreport + 1), np.nan)  # storage of bed elevation profiles

#########################################################################
#                               TIME LOOP                               #
#########################################################################

for t in range(0, Nt):
    # Computation of the flow using backwater equations
    [H, xi] = flow_computation(eta, xi_d, qw, kc, dx, Nx, g)

    # Computation of the sediment transport
    qt = np.zeros((Nx + 1, 1))  # qt, sediment transport rate in m2/s, is set to zero
    qt_u = 0  # upstream input set at 0 for no sediment transport

    # Bed variations
    eta = bed_variations(eta, qt, qt_u, If, lamp, dx, Nx, au, dt)

    # outputs
    # - store the profiles of xi and eta when t is a multiple of treport
    # (each column = profile at a given time)
    if t == 0:  # the first column containing the initial profile
        xir[:, 0] = xi[:, 0]
        etar[:, 0] = eta[:, 0]
    elif (
        (t / treport) - np.floor((t / treport))
    ) == 0:  # the following columns contain the profiles at time t=treport, t=2*treport
        xir[:, int(t / treport)] = xi[:, 0]
        etar[:, int(t / treport)] = eta[:, 0]

##############################################################################
#                        VISUALISATION                                       #
##############################################################################

ax = plt.subplot(111)
colours = plt.cm.coolwarm(np.linspace(0, 1, Nreport + 1))
for i in range(Nreport + 1):
    a = str(np.round((i / Nreport) * Durat, decimals=2))
    plt.plot(xcoord, xir[:, i], color=colours[i], linestyle="--", linewidth=1.0)
    plt.plot(
        xcoord, etar[:, i], color=colours[i], linestyle="-", linewidth=1.0, label=a
    )
plt.legend(title="time (years)", frameon=False)
ax.spines["right"].set_visible(False)
ax.spines["top"].set_visible(False)

plt.xlim(0, L)
plt.ylim(np.min(etar[-1, :]), np.max(xir[0, :]))
xtick = ax.get_xticks().tolist()

ax.ticklabel_format(axis="x", style="sci", scilimits=(0, 0))

plt.xlabel("distance along the river (m)")
plt.ylabel("height above datum (m)")
plt.show()
