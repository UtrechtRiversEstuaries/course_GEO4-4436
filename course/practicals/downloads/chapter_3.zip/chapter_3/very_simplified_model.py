#  Very simple morphodynamic model:
#        - No flow computation
#       - Sediment transport depends only on the local slope with a
#        proportionality coefficient SedProp
# ------------------------------------------------------------------

# Package import
import numpy as np
import matplotlib.pyplot as plt

#    INITIALISATION
#    Channel and bed characteristics

L = 11  # Length of reach under consideration (m)
S0 = 0.1  # Initial bed Slope (-)
SedProp = (
    0.1  # Sediment transport proportionality (to slope) including pore space (m2/s)
)

#   Parameters for discretisation:
#   - in space
dx = 1  # Spatial step (m)
#   - in time
Durat = 1001  # Duration of the run (s)
dt = 1  # Time step (s)
Nt = np.round(Durat / dt).astype(int)  # Number of time steps

#   Initialisation bathymetry
xcoord = np.transpose(np.arange(0, L, dx))  # spatial coordinates (m)
# eta = ???                      # bed elevation (m)

# COMPUTATION OF THE TIME EVOLUTION OF THE BED
fig = plt.figure(1)
for t in range(0, Nt):  # time loop
    # TO ADD:
    # - computation of the vector containing the sediment transport rate at the different nods qt (m2/s)
    # - computation of the sediment transport gradient dqdx(m/s)
    # - update of the vector containing the bed elevation eta(m)

    # visualisation
    # only plot data every 10 time steps (% = modulo)
    if t % 10 == 0:
        plt.clf()
        plt.plot(xcoord, eta)
        plt.xlim(0, L)
        plt.ylim(0, L * S0)
        plt.title("t =" + format(((t) * dt)) + "s")
        plt.xlabel("x(m)")
        plt.ylabel("$\eta(m)$")
        plt.show()
        plt.pause(0.0001)
        # Go to Tools - Preferences - iPython - Graphics Backened - Automatic - restart spyder
